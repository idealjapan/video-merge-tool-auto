#!/bin/bash

echo "=========================================="
echo "🎬 YouTube自動化 認証セットアップ"
echo "=========================================="
echo ""
echo "これから認証を行います。"
echo ""
echo "📌 重要："
echo "YouTubeチャンネルを所有している"
echo "Googleアカウントでログインしてください"
echo ""
echo "=========================================="
echo ""
read -p "準備ができたらEnterキーを押してください..."

# Pythonの確認
if command -v python3 &> /dev/null; then
    echo "✅ Python3を検出しました"
    python3 simple_youtube_setup.py
elif command -v python &> /dev/null; then
    echo "✅ Pythonを検出しました"
    python simple_youtube_setup.py
else
    echo "❌ Pythonが見つかりません"
    echo "Pythonをインストールしてください"
    exit 1
fi

echo ""
echo "=========================================="
echo "認証プロセスが完了しました"
echo ""
echo "✅ 成功した場合："
echo "   credentials/youtube_token.pickle"
echo "   が生成されています"
echo ""
echo "このファイルを開発環境にコピーしてください"
echo "=========================================="